#ifndef MYHEADER_APPMOD
#define MYHEADER_APPMOD

#include "art_method.h"

void appmod_guarding(const char* invoked_method,pid_t tid);

#endif




